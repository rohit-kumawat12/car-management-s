import { createContext } from "react";

const NoteContext = createContext();

export default NoteContext;