import React from "react";

const About = () => {
    return(
        <>
        About Us
        </>
    );
}

export default About;