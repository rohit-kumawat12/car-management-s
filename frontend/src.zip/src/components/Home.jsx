import React from "react";
import Cars from "././Cars";

const  Home = () => {

    return(
        <>
            <Cars />
        </>
    );
}

export default Home;